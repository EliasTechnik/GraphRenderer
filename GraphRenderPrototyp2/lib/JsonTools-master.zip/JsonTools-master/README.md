# JsonTools
A small pascal based json parser in one unit with no dependencies.

Please visit this [page](https://www.getlazarus.org/json/) for a complete guide on how to use this parser.
